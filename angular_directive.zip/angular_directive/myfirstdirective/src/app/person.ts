export interface Person {
    id: number;
    name: string;
    gender?: string;
  }
  
  export const Persons: Person[] = [
    { id: 1, name: 'Nishant', gender: 'Male'},
    { id: 2, name: 'Disha', gender: 'Female' },
    { id: 3, name: 'Priya', gender: 'Female' },
    { id: 4, name: 'Dheer',gender: 'Male'}
  ];
  